module TetraHelperDashMatchWall

using ..Ahorn, Maple

@mapdef Entity "TetraHelper/DashMatchWall" DashMatchWall(
    x::Integer, y::Integer, width::Integer=Maple.defaultBlockWidth,
    height::Integer=Maple.defaultBlockHeight, dashes::Integer=1, GT::Bool=false
)

const placements = Ahorn.PlacementDict(
    "Dash Match Wall (Tetrahelper)" => Ahorn.EntityPlacement(
        DashMatchWall,
        "rectangle"
    )
)

Ahorn.minimumSize(entity::DashMatchWall) = 8, 8
Ahorn.resizable(entity::DashMatchWall) = true, true
Ahorn.selection(entity::DashMatchWall) = Ahorn.getEntityRectangle(entity)

function Ahorn.render(ctx::Ahorn.Cairo.CairoContext, entity::DashMatchWall, room::Maple.Room)
    x = Int(get(entity.data, "x", 0))
    y = Int(get(entity.data, "y", 0))

    width = Int(get(entity.data, "width", 32))
    height = Int(get(entity.data, "height", 32))

    Ahorn.drawRectangle(ctx, 0, 0, width, height, (0.0, 0.0, 1.0, 0.4), (0.0, 0.0, 1.0, 1.0))
end
end