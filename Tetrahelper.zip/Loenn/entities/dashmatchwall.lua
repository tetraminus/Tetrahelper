local utils = require("utils")
local DashMatchWall = {}

DashMatchWall.name = "TetraHelper/DashMatchWall"
DashMatchWall.depth = 0
DashMatchWall.color = {0.33, 0.33, 0.33, 0.8}
DashMatchWall.canResize = {true, true}
DashMatchWall.placements = {
    name = "Dash Match Wall (Tetrahelper)",
    data = {
        width = 8,
        height = 8,
		dashes = 1,
		GT = false
    }
}
function DashMatchWall.color()
		

		
			return {0.5, 0.25, 0.25, 0.8}
		
		

		
	
end

function DashMatchWall.rectangle(room, entity)
	
    return utils.rectangle(entity.x, entity.y, entity.width or 8, entity.height or 8)
end



return DashMatchWall
