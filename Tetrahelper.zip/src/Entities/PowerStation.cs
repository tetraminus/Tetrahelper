﻿using Celeste.Mod.Entities;
using Microsoft.Xna.Framework;
using Monocle;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Celeste.Mod.Tetrahelper.Entities
{
	[CustomEntity("Tetrahelper/PowerStation")]
	class PowerStation : Entity
    {

		// Token: 0x06002D25 RID: 11557 RVA: 0x00109B3C File Offset: 0x00107D3C
		private string Flag;

		public PowerStation(Vector2 position, EntityData data) : base(position)
		{
			

			base.Add(new PlayerCollider(new Action<Player>(this.OnPlayer), new Circle(60f, 16f, 16f), null));
			base.Add(this.sprite = GFX.SpriteBank.Create("lockdoor_temple_a"));
			this.sprite.Play("idle", false, false);
			this.sprite.Position = new Vector2(base.Width / 2f, base.Height / 2f);
			this.unlockSfxName = "event:/game/05_mirror_temple/key_unlock_dark";
			this.Flag = data.Attr(Flag, "PowerFlag");
					
			
		}

		// Token: 0x06002D26 RID: 11558 RVA: 0x00109C50 File Offset: 0x00107E50
		

		// Token: 0x06002D27 RID: 11559 RVA: 0x00109C8D File Offset: 0x00107E8D
		

		// Token: 0x06002D28 RID: 11560 RVA: 0x00109CC8 File Offset: 0x00107EC8
		private void OnPlayer(Player player)
		{
			if (!this.opening)
			{
				foreach (Follower follower in player.Leader.Followers)
				{
					if (follower.Entity is Key && !(follower.Entity as Key).StartedUsing)
					{
						this.TryOpen(player, follower);
						break;
					}
				}
			}
		}

		// Token: 0x06002D29 RID: 11561 RVA: 0x00109D4C File Offset: 0x00107F4C
		private void TryOpen(Player player, Follower fol)
		{
			
				this.opening = true;
				(fol.Entity as Key).StartedUsing = true;
				base.Add(new Coroutine(this.UnlockRoutine(fol), true));
			
			
		}

		// Token: 0x06002D2A RID: 11562 RVA: 0x00109DAB File Offset: 0x00107FAB
		private IEnumerator UnlockRoutine(Follower fol)
		{
			SoundEmitter emitter = SoundEmitter.Play(this.unlockSfxName, this, null);
			emitter.Source.DisposeOnTransition = true;
			Level level = this.SceneAs<Level>();
			Key key = fol.Entity as Key;
			this.Add(new Coroutine(key.UseRoutine(this.Center + new Vector2(0f, 2f)), true));
			yield return 1.2f;
			this.UnlockingRegistered = true;
			
			key.RegisterUsed();
			while (key.Turning)
			{
				yield return null;
			}
			this.Tag |= Tags.TransitionUpdate;
			this.Collidable = false;
			emitter.Source.DisposeOnTransition = false;
			yield return this.sprite.PlayRoutine("open", false);
			level.Shake(0.3f);
			Input.Rumble(RumbleStrength.Medium, RumbleLength.Medium);
			yield return this.sprite.PlayRoutine("burst", false);
			this.RemoveSelf();
			level.Session.SetFlag(Flag, true);


			yield break;
		}

		// Token: 0x040026BB RID: 9915
		public static ParticleType P_Appear;

		// Token: 0x040026BC RID: 9916
		public EntityID ID;

		// Token: 0x040026BD RID: 9917
		public bool UnlockingRegistered;

		// Token: 0x040026BE RID: 9918
		private Sprite sprite;

		// Token: 0x040026BF RID: 9919
		private bool opening;

		// Token: 0x040026C0 RID: 9920
		private bool stepMusicProgress;

		// Token: 0x040026C1 RID: 9921
		private string unlockSfxName;
	}
}
