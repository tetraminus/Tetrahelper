# Tetrahelper

- Contents:

-- Entitys:

--- Dash Match Wall:
can only pass through if you have a set amount of dashes.

-- Triggers:

