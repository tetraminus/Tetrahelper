namespace Celeste.Mod.Tetrahelper {
    public class TetrahelperModuleSession : EverestModuleSession {

    }
}
