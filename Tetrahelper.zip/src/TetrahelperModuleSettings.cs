namespace Celeste.Mod.Tetrahelper {
    public class TetrahelperModuleSettings : EverestModuleSettings {

    }
}
